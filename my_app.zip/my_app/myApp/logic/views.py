from django.shortcuts import render


def start_page(request):
    context = {
        'title': 'Home',
    }
    return render(request, 'start_page.html', context)


def why_page(request):
    context = {
        'title': 'Why',
    }
    return render(request, 'why_page.html', context)


def thanks_page(request):
    context = {
        'title': 'Thanks',
    }
    return render(request, 'thanks_page.html', context)
