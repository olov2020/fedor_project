from . import views
from django.urls import path

urlpatterns = [
    path('', views.start_page, name='start_page'),
    path('why/', views.why_page, name='why_page'),
    path('thanks/', views.thanks_page, name='thanks'),
]

