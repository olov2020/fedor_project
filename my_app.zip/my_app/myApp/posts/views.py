from django.views.generic import CreateView
from django.urls import reverse_lazy
from django.shortcuts import render

from .forms import PostForm
from .models import Post


class CreatePostView(CreateView):
    model = Post
    form_class = PostForm
    template_name = 'order_portrait_page.html'
    success_url = reverse_lazy('thanks')
    extra_context = {'title': 'Order'}
