from django.urls import path
from . import views

from .views import CreatePostView  # new

urlpatterns = [
    path('order-portrait/', CreatePostView.as_view(), name='order_portrait'),
]